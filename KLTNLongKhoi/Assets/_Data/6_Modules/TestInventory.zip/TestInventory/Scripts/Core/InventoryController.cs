namespace KLTNLongKhoi
{
    //Logic for your inventory here
    public class InventoryController : ContainerBase
    {

    }
}