﻿namespace KLTNLongKhoi
{
    //class that will help you save items to your chest.
    public class StorageItem
    {
        public InventoryItem item;
        public int itemsCount;
    }
}
