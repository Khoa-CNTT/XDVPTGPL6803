
using UnityEngine;

namespace KLTNLongKhoi
{
    //just an override of base item
    [CreateAssetMenu(fileName = "Item", menuName = "ScriptableObjects/InventoryItems/ArmorItem", order = 1)]
    public class ArmorItem : InventoryItem
    {
        public float defensePoints = 5;
    }
}